package com.example.aula3b

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //buscar a referencia dos componentes da view  -  R= classe research(pesquisar)  -  textView= so exibe algo      Edittext= é modificavel(vc pode  preencher)
        var txtMensagem = findViewById<TextView>(R.id.txtMensagem)
        var edtNome = findViewById<EditText>(R.id.edtNome)
        var btnCadastrar = findViewById<Button>(R.id.btnCadastrar)

        //criar variável local
        var mensagem = "Aula 03 de Android!"

        //atribuir o valor desta variável para o txtMensagem
        txtMensagem.text = mensagem

        //configurar a ação de clique do botão btnCadastrar
        btnCadastrar.setOnClickListener {
            //SEMPRE VAI SER STRING, idependente se for number,boolean...
            if (edtNome.text.isEmpty()) {
                Toast.makeText(this, "Informe o nome antes", Toast.LENGTH_LONG).show()
            } else {
                var nome = edtNome.text.toString()

                //mostrar nome do cadastrado dentro de um toast                                show:mostra o codigo no app
                Toast.makeText(this, "Nome cadastrado: $nome", Toast.LENGTH_LONG).show()

                //limpar o campo edtNome
                edtNome.text.clear() //edtNome = ''
            }

        }
    }
}






