package com.example.aula6

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.aula6.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var dadosLogin: DadosLogin

    //criar variavel do tipo shared preferences
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityLoginBinding.inflate(layoutInflater)

        setContentView(binding.root)

        //inicializar o sharedPreferences
        dadosLogin = DadosLogin(applicationContext) //pode usar 'this' como parametro

        // ação de clique para o botão btnEntrar
        binding.btnEntrar.setOnClickListener {
            validarCampos()
        }

        //ação de clique para o botão btnPrimeiroAcesso
        binding.btnPrimeiroAcesso.setOnClickListener {
            var intent = Intent( this, CadastroActivity::class.java)
            startActivity(intent)
        }

    }

    private fun validarCampos() {

        if (binding.edtEmail.text.isEmpty() ||
            binding.edtSenha.text.isEmpty()
        ) {
            exibirToast("Preencha todos os campos!")
            return //encerramos a execução da função
        }

        var email = binding.edtEmail.text.toString()
        var senha = binding.edtSenha.text.toString()

        //verificar se o checkbox foi clicado

        var sharedEmail = dadosLogin.getEmail()
        var sharedSenha = dadosLogin.getSenha()

        var valoresDiferentes = email != sharedEmail || senha != sharedSenha

        if (valoresDiferentes) {

            exibirToast("E-mail ou Senha inválidos!")
            binding.edtEmail.text.clear()
            binding.edtSenha.text.clear()
            return
        }
        //redirecionar para MainActivity
        var intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        //matar essa activity
        finish()
    }


    private fun exibirToast(mensagem: String) {
        Toast.makeText(this, mensagem, Toast.LENGTH_SHORT).show()
    }
}
