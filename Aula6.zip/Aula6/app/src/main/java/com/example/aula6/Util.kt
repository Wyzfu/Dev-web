package com.example.aula6

import android.content.Context
import android.widget.Toast

class Util private constructor(){

    companion object {
        fun exibirToast(context : Context, msg : String) {
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }

    object Constantes {
        val CHAVE_EMAIL = "email"
        val CHAVE_SENHA = "senha"
        val CHAVE_LOGADO = "logado"
    }

}