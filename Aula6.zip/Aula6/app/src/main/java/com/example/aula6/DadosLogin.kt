package com.example.aula6

import android.content.Context
import android.provider.ContactsContract.CommonDataKinds.Email

class DadosLogin (context : Context) {

    private var sharedPreferences = context.getSharedPreferences("Login", Context.MODE_PRIVATE)
    private val EMAIL = "ana@gmail.com"
    private val SENHA = "123"
    private val LOGADO = false

    fun salvarDadosLogin (email: String, senha : String) {
        sharedPreferences.edit()
            .putString(Util.Constantes.CHAVE_EMAIL,email)
            .putString(Util.Constantes.CHAVE_SENHA,senha)
            .apply()
    }

    fun continuarLogado(valor : Boolean) {
        sharedPreferences.edit()
            .putBoolean(Util.Constantes.CHAVE_LOGADO, valor)
            .apply()
    }

    fun getLogado() : Boolean {
        return sharedPreferences.getBoolean(Util.Constantes.CHAVE_LOGADO, LOGADO) ?: false
    }

    fun getEmail() : String{
        return sharedPreferences.getString(Util.Constantes.CHAVE_EMAIL, EMAIL) ?: ""

    }

    fun getSenha() : String {
        return sharedPreferences.getString(Util.Constantes.CHAVE_SENHA, SENHA) ?:""
    }
}