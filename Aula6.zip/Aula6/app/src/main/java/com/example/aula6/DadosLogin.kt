package com.example.aula6

import android.content.Context
import android.provider.ContactsContract.CommonDataKinds.Email

class DadosLogin (context : Context) {

    private var sharedPreferences = context.getSharedPreferences("Login", Context.MODE_PRIVATE)
    private val EMAIL = "ana@gmail.com"
    private val SENHA = "123"

    fun salvarDadosLogin (email: String, senha : String) {
        sharedPreferences.edit()
            .putString("email",email)
            .putString("senha", senha)
            .apply()
    }

    fun getEmail() : String{
        return sharedPreferences.getString("email", EMAIL) ?: ""

    }

    fun getSenha() : String {
        return sharedPreferences.getString("senha", SENHA) ?:""
    }
}