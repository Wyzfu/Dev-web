package com.example.aula5

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.aula5.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    //criar referencia ao new binding desta classe
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //inicializar o objeto binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        //acima estamos ''iflando'' o layout do activity_main.xml para dentro do objeto binding

        //setar o binding como layout desta classe
        var view = binding.root
        setContentView(view)

        //Acessar os componenetes textviews utilizando o view binding
        binding.txtBox1.text = "Azul"
        binding.txtBox2.text = "Verde"
        binding.txtBox3.text = "Verde lima"
        binding.txtBox4.text = "Amarelo"

        //configurar a ação de clique do botão
        binding.btnAbrir.setOnClickListener {

            //configurar intent para acessar a segunda activity   intent= passa dados de uma activity para outra
            var intent = Intent(this, SegundaActivity::class.java)

            //iniciar SegundaActivity
            startActivity(intent)
        }
    }
}