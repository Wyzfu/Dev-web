package com.example.aula4

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.aula4.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    //ativar o binding no projeto
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //instanciar efetivamente o objeto binding
        binding = ActivityMainBinding.inflate(layoutInflater)

        //seta o layout do main_activity.xml, que está dentro
        //do ActivityMainBinding e copia todos os elementos de view para dentro da variável view
        var view = binding.root

        //por fim, setamos esta variavel como sendo o layout de nossa classe
        setContentView(view)

        //acessar os componentes da view, basta chamarmos binding.componente
        binding.btnCadastrar.setOnClickListener {

            if (binding.edtNome.text.isEmpty() || binding.edtIdade.text.isEmpty() ||
                    binding.edtEmail.text.isEmpty()){
                Toast.makeText(this, "Preencha tudo >:(", Toast.LENGTH_SHORT).show()
            }else{

                var nome = binding.edtNome.text.toString()
                var idade = binding.edtIdade.text.toString()
                var email = binding.edtEmail.text.toString()

                var cadastro = "Dados cadastrados \nNome: $nome\nIdade: $idade\nEmail: $email"

                binding.txtCadastro.text = cadastro

                //limpar os edtText
                binding.edtEmail.text.clear()
                binding.edtIdade.text.clear()
                binding.edtNome.text.clear()

            }
        }


        binding.btnAbrir.setOnClickListener {

            var intent = Intent(this, NewActivity::class.java)
            startActivity(intent)
        }



    }
}