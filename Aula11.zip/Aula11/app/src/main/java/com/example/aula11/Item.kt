package com.example.aula11

data class Item(var nome: String, var qtde: Int)