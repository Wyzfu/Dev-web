package com.example.aula11

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class ItemAdapter : RecyclerView.Adapter<ItemViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val layoutView = LayoutInflater.from(parent.context)
            .inflate(R.layout.layout_item, parent, false)
        return ItemViewHolder(layoutView)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val itemAtualdaLista = ItemData.listaItens[position]
        holder.nomeView.text = itemAtualdaLista.nome
        holder.qtdeView.text = "Quantidade" + itemAtualdaLista.qtde.toString()
    }

    override fun getItemCount(): Int {
        return ItemData.getTamanhoLista()
    }
}