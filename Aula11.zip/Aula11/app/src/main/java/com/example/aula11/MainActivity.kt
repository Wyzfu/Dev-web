package com.example.aula11

import android.content.Intent
import android.os.Binder
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.aula11.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding : ActivityMainBinding
    private lateinit var itemAdapter: ItemAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnNovoProduto.setOnClickListener {
            //iniciar a CadastroActivity
            startActivity(Intent(this, Cadastro:: class.java))

        }

        //informar p contexo em que a recycler view será inicializada
        //para isso, utilizamos a classe de apoio LinearLayoutManager
        binding.rclItems.layoutManager = LinearLayoutManager(this)
        //instanciar o objeto do tipo itemAdapter
        var itemAdapter = ItemAdapter()
        //setar o adapter criado para recycler view
        binding.rclItems.adapter = itemAdapter
    }

    override  fun onStart() {
        super.onStart()
        //atualizar itens da recycler
        itemAdapter.notifyDataSetChanged()
    }

}